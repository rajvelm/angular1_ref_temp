import { Component } from '@angular/core';

@Component({
  selector: 'app-nt-emp',
  templateUrl: './nt-emp.component.html',
  styleUrls: ['./nt-emp.component.css']
})
export class NtEmpComponent {

}
