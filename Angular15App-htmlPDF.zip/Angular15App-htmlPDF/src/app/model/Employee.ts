export interface Employee{
    EmployeeId:string;
    EmployeeName: string;
    Department: string;
    DateOfJoining: string;
    PhotoFileName: string;
}