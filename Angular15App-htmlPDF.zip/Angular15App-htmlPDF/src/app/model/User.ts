export interface User{
    Id: string;
    Name: string;
    UserName: string;
    Email: string;   
}