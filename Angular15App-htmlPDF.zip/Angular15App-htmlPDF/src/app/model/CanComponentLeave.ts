export interface CanComponentLeave{
    canLeave: () =>boolean;
   }