export interface UserMaster{
        Userid: string;   
        Username: string;
        Email: string;   
        Password:string;
        Role: string,
        Isactive: boolean   
}

